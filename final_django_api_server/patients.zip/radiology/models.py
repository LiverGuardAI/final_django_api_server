# radiology/models.py
from django.db import models


class Radiology(models.Model):
    """영상의학과"""

    radiologic_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    employee_no = models.CharField(max_length=50, unique=True)
    date_of_birth = models.DateField(blank=True, null=True)
    license_no = models.CharField(max_length=150)
    phone = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    user = models.OneToOneField('accounts.CustomUser', on_delete=models.CASCADE, db_column='user_id')
    department = models.ForeignKey('accounts.Department', on_delete=models.RESTRICT, db_column='department_id')
    
    class Meta:
        db_table = 'hospital"."radiology'
        verbose_name = '영상의학과'
        verbose_name_plural = '영상의학과'


class DICOMStudy(models.Model):
    """DICOM 스터디"""

    study_uid = models.CharField(max_length=64, primary_key=True)
    order_id = models.BigIntegerField(blank=True, null=True)
    orthanc_study_id = models.CharField(max_length=64, blank=True, null=True)
    accession_number = models.CharField(max_length=64, blank=True, null=True)
    modality = models.CharField(max_length=16, blank=True, null=True)
    body_part = models.CharField(max_length=64, blank=True, null=True)
    study_description = models.CharField(max_length=255, blank=True, null=True)
    study_datetime = models.DateTimeField(blank=True, null=True)
    institution_name = models.CharField(max_length=64, blank=True, null=True)
    started_at = models.DateTimeField(blank=True, null=True)
    ended_at = models.DateTimeField(blank=True, null=True)
    post_processing_started_at = models.DateTimeField(blank=True, null=True)
    post_processing_completed_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    patient = models.ForeignKey('doctor.Patient', on_delete=models.CASCADE, to_field='patient_id', db_column='patient_id')
    encounter = models.ForeignKey('doctor.Encounter', on_delete=models.SET_NULL, null=True, blank=True, db_column='encounter_id')

    class Meta:
        db_table = 'hospital"."dicom_studies'


class DICOMSeries(models.Model):
    """DICOM 시리즈"""

    series_uid = models.CharField(max_length=64, primary_key=True)
    orthanc_series_id = models.CharField(max_length=64, blank=True, null=True)
    modality = models.CharField(max_length=16, blank=True, null=True)
    series_number = models.IntegerField(blank=True, null=True)
    series_description = models.CharField(max_length=255, blank=True, null=True)
    acquisition_datetime = models.DateTimeField(blank=True, null=True)
    image_count = models.IntegerField(blank=True, null=True)
    slice_thickness = models.DecimalField(max_digits=10, decimal_places=4, blank=True, null=True)
    pixel_spacing = models.CharField(max_length=64, blank=True, null=True)
    protocol_name = models.CharField(max_length=128, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    study = models.ForeignKey(DICOMStudy, on_delete=models.CASCADE, to_field='study_uid', db_column='study_uid')
    
    class Meta:
        db_table = 'hospital"."dicom_series'




class RadiologyAIRun(models.Model):
    """AI 실행 기록"""

    class RunStatus(models.TextChoices):
        PENDING = 'PENDING', '대기중'
        RUNNING = 'RUNNING', '분석중'
        COMPLETED = 'COMPLETED', '완료'
        FAILED = 'FAILED', '실패'

    run_id = models.AutoField(primary_key=True)
    task_type = models.CharField(max_length=30, blank=True, null=True)
    model_name = models.CharField(max_length=128, blank=True, null=True)
    # request_payload 제거됨
    status = models.CharField(
        max_length=20, 
        choices=RunStatus.choices, 
        default=RunStatus.PENDING
    )
    started_at = models.DateTimeField(blank=True, null=True)
    finished_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    mask_series_uid = models.CharField(max_length=64, blank=True, null=True)

    series = models.ForeignKey(DICOMSeries, on_delete=models.CASCADE, to_field='series_uid', db_column='series_uid')
    
    class Meta:
        db_table = 'hospital"."radiology_ai_runs'
        indexes = [
            models.Index(fields=['series']),
            models.Index(fields=['status']),
        ]


class RadiologyToDoctorOrder(models.Model):
    """영상의학과 -> 의사 오더 (추가 촬영 제안 등)"""

    class OrderStatus(models.TextChoices):
        REQUESTED = 'REQUESTED', '요청됨'
        CHECKED = 'CHECKED', '확인됨'
        CANCELLED = 'CANCELLED', '취소'

    rd_order_id = models.AutoField(primary_key=True)
    message = models.TextField(blank=True, null=True)
    priority = models.CharField(max_length=10, default='ROUTINE')
    status = models.CharField(
        max_length=20, 
        choices=OrderStatus.choices, 
        default=OrderStatus.REQUESTED
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Relations
    radiologist = models.ForeignKey(Radiology, on_delete=models.RESTRICT, db_column='radiologic_id')
    doctor = models.ForeignKey('doctor.Doctor', on_delete=models.CASCADE, db_column='doctor_id')
    patient = models.ForeignKey('doctor.Patient', on_delete=models.CASCADE, db_column='patient_id')
    encounter = models.ForeignKey('doctor.Encounter', on_delete=models.CASCADE, db_column='encounter_id', null=True, blank=True)
    
    class Meta:
        db_table = 'hospital"."radiology_to_doctor_orders'


class CTReport(models.Model):
    """CT 보고서"""

    report_id = models.AutoField(primary_key=True)
    series_instance_uid = models.CharField(max_length=64, db_index=True)
    report_text = models.TextField()
    tumor_analysis = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'hospital"."ct_reports'
