# radiology/serializers.py
from rest_framework import serializers
from doctor.models import Patient, DoctorToRadiologyOrder, Encounter
from .models import DICOMStudy, CTReport


class PatientWaitlistSerializer(serializers.ModelSerializer):
    """촬영 대기 환자 정보 시리얼라이저"""

    class Meta:
        model = Patient
        fields = [
            'patient_id',
            'name',
            'date_of_birth',
            'age',
            'gender',
            'created_at',
            'updated_at',
        ]


class EncounterWaitlistSerializer(serializers.ModelSerializer):
    """촬영 대기/촬영중 환자 정보 (Encounter 기반)"""

    patient_id = serializers.CharField(source='patient.patient_id', read_only=True)
    name = serializers.CharField(source='patient.name', read_only=True)
    date_of_birth = serializers.DateField(source='patient.date_of_birth', read_only=True)
    age = serializers.IntegerField(source='patient.age', read_only=True)
    gender = serializers.CharField(source='patient.gender', read_only=True)
    current_status = serializers.SerializerMethodField()

    class Meta:
        model = Encounter
        fields = [
            'encounter_id',
            'patient_id',
            'name',
            'date_of_birth',
            'age',
            'gender',
            'workflow_state',
            'current_status',
            'state_entered_at',
        ]

    def get_current_status(self, obj):
        orders = getattr(obj, 'doctortoradiologyorder_set', None)
        if orders is not None:
            statuses = {order.status for order in orders.all()}
            if 'IN_PROGRESS' in statuses:
                return '촬영중'
            if 'WAITING' in statuses or 'REQUESTED' in statuses:
                return '촬영대기'
            if 'COMPLETED' in statuses:
                return '촬영완료'
        mapping = {
            Encounter.WorkflowState.WAITING_IMAGING: '촬영대기중',
            Encounter.WorkflowState.IN_IMAGING: '촬영중',
            Encounter.WorkflowState.COMPLETED: '촬영완료',
        }
        return mapping.get(obj.workflow_state, obj.workflow_state)


class RadiologyQueueSerializer(serializers.ModelSerializer):
    """촬영 대기열 정보 시리얼라이저 (DoctorToRadiologyOrder 기반)"""
    patient = PatientWaitlistSerializer(read_only=True)

    class Meta:
        model = DoctorToRadiologyOrder
        fields = [
            'order_id',
            'patient',
            'modality',
            'body_part',
            'scheduled_at',
            'status',
            'ordered_at',
            'study_uid',
        ]


class CTReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = CTReport
        fields = [
            'report_id',
            'series_instance_uid',
            'report_text',
            'tumor_analysis',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['report_id', 'created_at', 'updated_at']
