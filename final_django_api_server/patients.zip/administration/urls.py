from django.urls import path
from .views import (
    AdministrationDashboardView,
    PatientListView,
    PatientDetailView,
    PatientRegistrationView,
    AppointmentListView,
    AppointmentDetailView,
    EncounterListView,
    EncounterDetailView,
    WaitingQueueView,
    AdministrationWaitingQueueView,
    CallNextPatientView,
    DashboardStatsView,
    PendingOrdersView,
    InProgressOrdersView,
    ConfirmOrderView,
    AssignImagingDoctorView,
    AssignAdditionalClinicView,
    CompleteVitalOrPhysicalView,
    CancelEncounterView,
    DailyPatientStatusView,
    AdministrationInfoView,
)

urlpatterns = [
    # 원무과 직원 정보
    path('me/', AdministrationInfoView.as_view(), name='administration_info'),

    # 대시보드
    path('dashboard/', AdministrationDashboardView.as_view(), name='administration_dashboard'),
    path('dashboard/stats/', DashboardStatsView.as_view(), name='dashboard_stats'),
    path('dashboard/patient-status/', DailyPatientStatusView.as_view(), name='patient_status_stats'),

    # 환자 관리
    path('patients/', PatientListView.as_view(), name='patient_list'),
    path('patients/register/', PatientRegistrationView.as_view(), name='patient_registration'),
    path('patients/<str:patient_id>/', PatientDetailView.as_view(), name='patient_detail'),

    # 예약 관리
    path('appointments/', AppointmentListView.as_view(), name='appointment_list'),
    path('appointments/<int:appointment_id>/', AppointmentDetailView.as_view(), name='appointment_detail'),

    # 진료 기록 (접수)
    path('encounters/', EncounterListView.as_view(), name='encounter_list'),
    path('encounters/<int:encounter_id>/', EncounterDetailView.as_view(), name='encounter_detail'),

    # 대기열 관리 (Queue + Cache)
    path('queue/', WaitingQueueView.as_view(), name='waiting_queue'),  # /api/administration/queue/
    path('queue/waiting/', WaitingQueueView.as_view(), name='waiting_queue_alt'),  # 하위 호환성 유지
    path('queue/call-next/', CallNextPatientView.as_view(), name='call_next_patient'),

    # 원무과 전용 분리형 대기열
    path('queue/admin/', AdministrationWaitingQueueView.as_view(), name='admin_waiting_queue'),

    # 오더 관리 (추가진료 탭)
    path('orders/pending/', PendingOrdersView.as_view(), name='pending_orders'),
    path('orders/in-progress/', InProgressOrdersView.as_view(), name='in_progress_orders'),
    path('orders/<int:order_id>/confirm/', ConfirmOrderView.as_view(), name='confirm_order'),
    path('orders/<int:order_id>/assign-doctor/', AssignImagingDoctorView.as_view(), name='assign_imaging_doctor'),
    path('orders/radiology-request/<int:order_id>/assign-additional/', AssignAdditionalClinicView.as_view(), name='assign_additional_clinic'),
    path('orders/<int:order_id>/complete-vital/', CompleteVitalOrPhysicalView.as_view(), name='complete_vital'),
    path('encounters/<int:encounter_id>/cancel/', CancelEncounterView.as_view(), name='cancel_encounter'),
]
