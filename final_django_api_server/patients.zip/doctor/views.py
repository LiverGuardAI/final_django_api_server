from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from accounts.permissions import IsDoctor
from .models import Encounter, MedicalRecord, Patient, Doctor, LabResult, DoctorToRadiologyOrder, HCCDiagnosis, GenomicData, LabOrder, AnthropometricData, Announcement, ScheduleDoctor, Questionnaire, VitalData, Prescription
from radiology.models import DICOMStudy, DICOMSeries
from .serializers import (
    EncounterSerializer, MedicalRecordSerializer, UpdateEncounterStatusSerializer, DoctorListSerializer,
    MedicalRecordDetailSerializer, LabResultSerializer, DoctorToRadiologyOrderSerializer,
    HCCDiagnosisSerializer, GenomicDataSerializer, CreateLabOrderSerializer,
    CreateDoctorToRadiologyOrderSerializer, LabOrderSerializer, AnnouncementSerializer, ScheduleDoctorSerializer,
    QuestionnaireSerializer, VitalDataSerializer
)
from administration.serializers import PatientSerializer
from administration.models import Administration
from datetime import date, datetime
from django.utils import timezone
from django.db.models import Q, F
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from administration.cache_manager import cache_manager
from services.report_lmstudio import generate_lmstudio_report


class DoctorDashboardView(APIView):
    """의사 전용 대시보드 API"""
    permission_classes = [IsDoctor]

    def get(self, request):
        user = request.user

        # 진료실 대기 환자 (WAITING_CLINIC만)
        clinic_waiting = Encounter.objects.filter(
            workflow_state__in=[
                Encounter.WorkflowState.WAITING_CLINIC,
                Encounter.WorkflowState.WAITING_ADDITIONAL_CLINIC
            ]
        ).count()

        # 진료 중 환자 (IN_CLINIC만)
        clinic_in_progress = Encounter.objects.filter(
            workflow_state=Encounter.WorkflowState.IN_CLINIC
        ).count()

        today = timezone.now().date()

        # 진료 후 처리 중인 환자 (수납 대기, 결과 대기, 촬영 대기/중)
        post_clinic_states = [
            Encounter.WorkflowState.WAITING_PAYMENT,
            Encounter.WorkflowState.WAITING_RESULTS,
            Encounter.WorkflowState.WAITING_ORDER,
            Encounter.WorkflowState.WAITING_IMAGING,
            Encounter.WorkflowState.IN_IMAGING,
        ]
        
        # 1. 진료 후 처리 중인 환자 수
        post_clinic_count = Encounter.objects.filter(
            workflow_state__in=post_clinic_states
        ).count()

        # 2. 오늘 진료 완료(수납까지 완료)된 환자 수
        completed_today_count = Encounter.objects.filter(
            workflow_state=Encounter.WorkflowState.COMPLETED,
            updated_at__date=today
        ).count()

        completed_today = post_clinic_count + completed_today_count

        return Response({
            'message': f'안녕하세요, {user.first_name} 의사님',
            'user': {
                'id': user.user_id,
                'username': user.username,
                'role': user.role,
                'first_name': user.first_name,
                'last_name': user.last_name,
            },
            'stats': {
                'total_patients': clinic_waiting + clinic_in_progress + completed_today,
                'clinic_waiting': clinic_waiting,
                'clinic_in_progress': clinic_in_progress,
                'completed_today': completed_today,
            }
        }, status=status.HTTP_200_OK)


class PatientListView(APIView):
    """의사의 환자 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request):
        # 검색 쿼리
        search = request.query_params.get('search', '')

        # 환자 쿼리
        patients = Patient.objects.all()

        if search:
            # 커스텀 매니저 (search_patient) 사용
            patients = patients.search_patient(search).order_by('-similarity', '-created_at')
        else:
            patients = patients.order_by('-created_at')

        # Limit (선택적)
        limit = request.query_params.get('limit')
        if limit:
            patients = patients[:int(limit)]

        serializer = PatientSerializer(patients, many=True)

        return Response({
            'message': '환자 목록',
            'count': patients.count() if not limit else len(patients), # 슬라이싱 후에는 count() 호출 불가할 수 있음
            'patients': serializer.data
        }, status=status.HTTP_200_OK)



class ScheduleDoctorListView(APIView):
    permission_classes = [IsDoctor]

    def get(self, request):
        doctor = getattr(request.user, 'doctor', None)
        if not doctor:
            return Response({'error': 'Doctor profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        queryset = ScheduleDoctor.objects.filter(doctor=doctor)
        if start_date:
            queryset = queryset.filter(schedule_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(schedule_date__lte=end_date)

        serializer = ScheduleDoctorSerializer(queryset.order_by('schedule_date', 'start_time'), many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        doctor = getattr(request.user, 'doctor', None)
        if not doctor:
            return Response({'error': 'Doctor profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = ScheduleDoctorSerializer(data=request.data)
        if serializer.is_valid():
            schedule = serializer.save(doctor=doctor)
            return Response(ScheduleDoctorSerializer(schedule).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ScheduleDoctorDetailView(APIView):
    permission_classes = [IsDoctor]

    def patch(self, request, schedule_id):
        doctor = getattr(request.user, 'doctor', None)
        if not doctor:
            return Response({'error': 'Doctor profile not found.'}, status=status.HTTP_404_NOT_FOUND)
        try:
            schedule = ScheduleDoctor.objects.get(schedule_id=schedule_id, doctor=doctor)
        except ScheduleDoctor.DoesNotExist:
            return Response({'error': 'Schedule not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = ScheduleDoctorSerializer(schedule, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, schedule_id):
        doctor = getattr(request.user, 'doctor', None)
        if not doctor:
            return Response({'error': 'Doctor profile not found.'}, status=status.HTTP_404_NOT_FOUND)
        try:
            schedule = ScheduleDoctor.objects.get(schedule_id=schedule_id, doctor=doctor)
        except ScheduleDoctor.DoesNotExist:
            return Response({'error': 'Schedule not found.'}, status=status.HTTP_404_NOT_FOUND)
        schedule.delete()
        return Response({'message': 'Schedule deleted.'}, status=status.HTTP_200_OK)


class QueueListView(APIView):
    """의사의 환자 대기열 조회 API (Encounter 기반)"""
    permission_classes = [IsDoctor]

    def get(self, request):
        try:
            # 오늘 날짜
            today = timezone.now().date()

            # 쿼리 파라미터로 상태 필터링 (기본값: WAITING_CLINIC)
            encounter_status = request.query_params.get('status', 'WAITING_CLINIC')
            doctor_id = request.query_params.get('doctor_id')

            # Encounter 조회
            # 취소(CANCELLED)된 환자는 항상 제외
            # 수납 완료(COMPLETED)된 환자는 오늘 날짜인 경우만 포함 (오늘의 진료 내역 확인용)
            encounters = Encounter.objects.exclude(
                workflow_state=Encounter.WorkflowState.CANCELLED
            ).exclude(
                Q(workflow_state=Encounter.WorkflowState.COMPLETED) & ~Q(updated_at__date=today)
            )

            # 의사별 필터링 (본인 담당 환자만)
            if doctor_id:
                encounters = encounters.filter(assigned_doctor_id=doctor_id)

            # 상태별 필터링
            if encounter_status == 'ALL':
                # 모든 상태 (위에서 필터링된 범위 내)
                pass
            else:
                encounters = encounters.filter(workflow_state=encounter_status)

            # state_entered_at 순 정렬 (FIFO)
            encounters = encounters.order_by('state_entered_at')

            # Serialize
            serializer = EncounterSerializer(encounters, many=True)

            # 통계 정보
            base_qs = Encounter.objects.all()
            if doctor_id:
                base_qs = base_qs.filter(assigned_doctor_id=doctor_id)

            waiting_count = base_qs.filter(
                workflow_state__in=[
                    Encounter.WorkflowState.WAITING_CLINIC,
                    Encounter.WorkflowState.WAITING_ADDITIONAL_CLINIC
                ]
            ).count()

            in_progress_count = base_qs.filter(
                workflow_state=Encounter.WorkflowState.IN_CLINIC
            ).count()

            # 오늘 진료 완료된 환자 수
            completed_count = base_qs.filter(
                workflow_state=Encounter.WorkflowState.COMPLETED,
                updated_at__date=today
            ).count()

            return Response({
                'encounters': serializer.data,
                'stats': {
                    'waiting': waiting_count,
                    'in_progress': in_progress_count,
                    'completed': completed_count,
                    'total': waiting_count + in_progress_count + completed_count
                }
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UpdateEncounterStatusView(APIView):
    """Encounter 상태 변경 API (진료 시작/완료 등)"""
    permission_classes = [IsDoctor]

    def patch(self, request, encounter_id):
        try:
            # 해당 Encounter 조회
            encounter = Encounter.objects.get(encounter_id=encounter_id)

            # 요청 데이터 검증
            serializer = UpdateEncounterStatusSerializer(data=request.data)
            if serializer.is_valid():
                # 워크플로우 상태 변경 (backward compatibility: 'status' 필드도 허용)
                new_workflow_state = serializer.validated_data.get('workflow_state') or serializer.validated_data.get('status')

                if new_workflow_state:
                    # 통합 상태 변경 메서드 사용 (Redis 캐시 업데이트 포함)
                    current_location = serializer.validated_data.get('current_location')
                    encounter.transition_to(new_workflow_state, current_location)

                # 업데이트된 데이터 반환
                response_serializer = EncounterSerializer(encounter)
                return Response({
                    'message': '상태가 변경되었습니다.',
                    'encounter': response_serializer.data
                }, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Encounter.DoesNotExist:
            return Response({
                'error': '해당 방문 기록을 찾을 수 없습니다.'
            }, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DoctorListView(APIView):
    """의사 목록 조회 API (원무과 환자 접수용)"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """
        모든 의사 목록 조회

        Query params:
        - department: 부서 ID로 필터링 (선택)
        """
        try:
            doctors = Doctor.objects.select_related('department').all()

            # 부서별 필터링
            department_id = request.query_params.get('department', None)
            if department_id:
                doctors = doctors.filter(department_id=department_id)

            # 검색 필터 (이름, 사번)
            search = request.query_params.get('search', '')
            if search:
                # 커스텀 매니저 (search_doctor) 사용
                doctors = doctors.search_doctor(search).order_by('-similarity', 'name')
            else:
                doctors = doctors.order_by('name')

            serializer = DoctorListSerializer(doctors, many=True)

            return Response({
                'count': doctors.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class MedicalRecordDetailView(APIView):
    """MedicalRecord 상세 정보 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, record_id):
        try:
            # 1. 현재 로그인한 의사 정보 가져오기
            current_doctor = Doctor.objects.get(user=request.user)

            # 2. MedicalRecord 조회
            medical_record = MedicalRecord.objects.select_related(
                'patient', 'doctor', 'staff', 'diagnosis_type', 'encounter'
            ).get(record_id=record_id)

            # 3. 권한 검사
            if medical_record.doctor and medical_record.doctor.doctor_id != current_doctor.doctor_id:
                return Response({
                    'error': '본인의 진료 기록이 아닙니다.'
                }, status=status.HTTP_403_FORBIDDEN)

            # 4. 데이터 반환
            serializer = MedicalRecordDetailSerializer(medical_record)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Doctor.DoesNotExist:
            return Response({'error': '의사 정보를 찾을 수 없습니다.'}, status=404)
        except MedicalRecord.DoesNotExist:
            return Response({'error': '해당 진료 기록을 찾을 수 없습니다.'}, status=404)
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class EncounterDetailView(APIView):
    """
    Encounter 상세 정보 조회 API
    - 의사: 진료 및 처방 가능
    - 원무과: 조회 전용 (진료비 수납 등 확인용)
    """
    permission_classes = [IsAuthenticated]  # 의사 + 원무과 모두 접근 허용

    def get(self, request, encounter_id):
        try:
            encounter = Encounter.objects.get(encounter_id=encounter_id)
            
            # 해당 Encounter와 연결된 MedicalRecord 조회
            # (진료 완료된 기록을 우선 찾고, 없으면 가장 최근 기록)
            medical_record = encounter.medical_records.filter(
                record_status=MedicalRecord.RecordStatus.COMPLETED
            ).last()
            
            if not medical_record:
                # 완료된 기록이 없으면 작성 중인 기록이라도 조회
                medical_record = encounter.medical_records.last()
            
            if medical_record:
                # 진료 기록이 있으면 상세 정보 반환 (진단명, 오더 등 포함)
                serializer = MedicalRecordDetailSerializer(medical_record)
            else:
                # 진료 기록이 아직 생성되지 않았으면 기본 Encounter 정보 반환 (대기 중 상태 등)
                # 주의: 프론트엔드에서 필드 차이 처리 필요할 수 있음
                serializer = EncounterSerializer(encounter)
                
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Encounter.DoesNotExist:
            return Response({'error': '해당 방문 기록을 찾을 수 없습니다.'}, status=404)
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class MedicalRecordSaveView(APIView):
    """진료 기록 임시 저장 API"""
    permission_classes = [IsDoctor]

    def post(self, request):
        try:
            doctor = Doctor.objects.get(user=request.user)

            encounter_id = request.data.get('encounter_id')
            patient_id = request.data.get('patient_id')
            if not encounter_id or not patient_id:
                return Response({'error': 'encounter_id와 patient_id가 필요합니다.'}, status=status.HTTP_400_BAD_REQUEST)

            encounter = Encounter.objects.select_related('patient').get(encounter_id=encounter_id)
            if str(encounter.patient_id) != str(patient_id):
                return Response({'error': '환자 정보가 일치하지 않습니다.'}, status=status.HTTP_400_BAD_REQUEST)

            staff = getattr(request.user, 'administration', None)
            if not staff:
                staff = Administration.objects.order_by('staff_id').first()
            if not staff:
                return Response({'error': '원무과 직원 정보를 찾을 수 없습니다.'}, status=status.HTTP_400_BAD_REQUEST)

            medical_record, created = MedicalRecord.objects.get_or_create(
                encounter=encounter,
                patient=encounter.patient,
                defaults={
                    'record_date': timezone.now().date(),
                    'record_time': timezone.now().time(),
                    'doctor': doctor,
                    'staff': staff,
                    'record_status': MedicalRecord.RecordStatus.DRAFT,
                    'clinic_room': doctor.room_number,
                    'department': doctor.department.dept_name if doctor.department else None,
                }
            )

            chief_complaint = request.data.get('chief_complaint')
            clinical_notes = request.data.get('clinical_notes')
            record_status = request.data.get('record_status')
            if record_status:
                valid_statuses = {choice[0] for choice in MedicalRecord.RecordStatus.choices}
                if record_status not in valid_statuses:
                    return Response({'error': '유효하지 않은 기록 상태입니다.'}, status=status.HTTP_400_BAD_REQUEST)

            if chief_complaint is not None:
                medical_record.chief_complaint = chief_complaint
            if clinical_notes is not None:
                medical_record.clinical_notes = clinical_notes

            if not medical_record.doctor_id:
                medical_record.doctor = doctor
            if not medical_record.staff_id:
                medical_record.staff = staff
            if not medical_record.record_date:
                medical_record.record_date = timezone.now().date()
            if not medical_record.record_time:
                medical_record.record_time = timezone.now().time()
            if not medical_record.clinic_room:
                medical_record.clinic_room = doctor.room_number or encounter.current_location
            if not medical_record.department and doctor.department:
                medical_record.department = doctor.department.dept_name

            if record_status:
                medical_record.record_status = record_status
            elif not medical_record.record_status:
                medical_record.record_status = MedicalRecord.RecordStatus.DRAFT
            medical_record.save()

            print(f"DEBUG: {request.data}")
            # 처방 약물 저장 로직
            medications = request.data.get('medications')
            if medications is not None: 
                # 기존 처방 삭제 (덮어쓰기 로직 - 수정 시 중복 방지)
                Prescription.objects.filter(encounter=encounter).delete()
                
                for med in medications:
                    try:
                        # days 값을 정수로 변환 (없으면 None)
                        days_int = int(med.get('days', 0)) if med.get('days') else None
                        
                        Prescription.objects.create(
                            patient=encounter.patient,
                            encounter=encounter,
                            doctor=doctor,
                            department=doctor.department,
                            prescription_date=timezone.now().date(),
                            item_seq=0, # 임시 시퀀스 값
                            medication_name=med.get('name', ''),
                            dosage=med.get('dosage', ''),
                            frequency=med.get('frequency', ''),
                            duration_days=days_int
                        )
                    except Exception as e:
                        print(f"Prescription create failed: {e}")

            serializer = MedicalRecordDetailSerializer(medical_record)
            return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)
        except Doctor.DoesNotExist:
            return Response({'error': '의사 정보를 찾을 수 없습니다.'}, status=status.HTTP_404_NOT_FOUND)
        except Encounter.DoesNotExist:
            return Response({'error': '해당 방문 기록을 찾을 수 없습니다.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientMedicalRecordHistoryView(APIView):
    """특정 환자의 과거 진료 기록 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        """
        특정 환자의 과거 진료 기록 목록 조회
        """
        try:
            medical_records = MedicalRecord.objects.filter(
                patient_id=patient_id
            ).select_related('doctor', 'staff', 'diagnosis_type', 'encounter').order_by('-record_date', '-record_time')

            # 최근 N개만 조회 (선택적)
            limit = request.query_params.get('limit', None)
            if limit:
                medical_records = medical_records[:int(limit)]

            serializer = MedicalRecordDetailSerializer(medical_records, many=True)
            return Response({
                'count': medical_records.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# Backward compatibility alias
PatientEncounterHistoryView = PatientMedicalRecordHistoryView


class PatientQuestionnaireHistoryView(APIView):
    """특정 환자의 문진표 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        try:
            questionnaires = Questionnaire.objects.filter(
                encounter__patient_id=patient_id
            ).select_related('encounter').order_by('-updated_at')

            limit = request.query_params.get('limit')
            if limit:
                questionnaires = questionnaires[:int(limit)]

            serializer = QuestionnaireSerializer(questionnaires, many=True)
            return Response({
                'count': questionnaires.count() if not limit else len(questionnaires),
                'results': serializer.data,
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientVitalHistoryView(APIView):
    """특정 환자의 바이탈 기록 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        try:
            vitals = VitalData.objects.filter(
                patient_id=patient_id
            ).order_by('-measured_at', '-vital_id')

            limit = request.query_params.get('limit')
            if limit:
                vitals = vitals[:int(limit)]

            serializer = VitalDataSerializer(vitals, many=True)
            return Response({
                'count': vitals.count() if not limit else len(vitals),
                'results': serializer.data,
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientLabResultsView(APIView):
    """특정 환자의 혈액 검사 결과 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        """
        특정 환자의 혈액 검사 결과 목록 조회
        """
        try:
            lab_results = LabResult.objects.filter(
                patient_id=patient_id
            ).order_by('-test_date')

            # 최근 N개만 조회 (선택적)
            limit = request.query_params.get('limit', None)
            if limit:
                lab_results = lab_results[:int(limit)]

            serializer = LabResultSerializer(lab_results, many=True)
            return Response({
                'count': lab_results.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientProfileView(APIView):
    """특정 환자의 기본 정보 + 최신 신체계측"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            latest_anthro = (
                AnthropometricData.objects.filter(patient_id=patient_id)
                .order_by(F('measured_at').desc(nulls_last=True), '-anthro_id')
                .first()
            )

            return Response({
                'patient_id': patient.patient_id,
                'name': patient.name,
                'age': patient.age,
                'gender': patient.gender,
                'height': latest_anthro.height if latest_anthro else None,
                'weight': latest_anthro.weight if latest_anthro else None,
                'measured_at': latest_anthro.measured_at if latest_anthro else None,
            }, status=status.HTTP_200_OK)

        except Patient.DoesNotExist:
            return Response({
                'error': 'Patient not found'
            }, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class PatientDoctorToRadiologyOrdersView(APIView):
    """특정 환자의 영상 검사 오더 목록 조회 API (의사 -> 영상의학과)"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        """
        특정 환자의 영상 검사 오더 목록 조회
        """
        try:
            imaging_orders = DoctorToRadiologyOrder.objects.filter(
                patient_id=patient_id
            ).select_related('doctor').order_by('-ordered_at')

            # 최근 N개만 조회 (선택적)
            limit = request.query_params.get('limit', None)
            if limit:
                imaging_orders = imaging_orders[:int(limit)]

            serializer = DoctorToRadiologyOrderSerializer(imaging_orders, many=True)
            return Response({
                'count': imaging_orders.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientHCCDiagnosisView(APIView):
    """특정 환자의 HCC 진단 정보 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        """
        특정 환자의 HCC 진단 정보 조회
        """
        try:
            hcc_diagnoses = HCCDiagnosis.objects.filter(
                patient_id=patient_id
            ).order_by(F('measured_at').desc(nulls_last=True), '-hcc_diagnosis_date', '-hcc_id')

            serializer = HCCDiagnosisSerializer(hcc_diagnoses, many=True)
            return Response({
                'count': hcc_diagnoses.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientGenomicDataView(APIView):
    """특정 환자의 유전체 검사 데이터 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        try:
            genomic_qs = GenomicData.objects.filter(
                patient_id=patient_id
            ).order_by('-sample_date', '-genomic_id')

            limit = request.query_params.get('limit', None)
            if limit:
                genomic_qs = genomic_qs[:int(limit)]

            return Response({
                'count': genomic_qs.count(),
                'results': GenomicDataSerializer(genomic_qs, many=True).data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PatientCTSeriesView(APIView):
    """특정 환자의 CT 시리즈 목록 조회 API"""
    permission_classes = [IsDoctor]

    def get(self, request, patient_id):
        try:
            study_uids = list(
                DICOMStudy.objects.filter(patient_id=patient_id)
                .values_list('study_uid', flat=True)
            )
            if not study_uids:
                return Response({'count': 0, 'results': []}, status=status.HTTP_200_OK)

            series_qs = (
                DICOMSeries.objects.filter(study_id__in=study_uids, modality='CT')
                .select_related('study')
                .values(
                    'series_uid',
                    'study_id',
                    'series_description',
                    'series_number',
                    'modality',
                    'study__study_datetime',
                    'study__body_part',
                    'acquisition_datetime',
                    'image_count',
                    'slice_thickness',
                    'pixel_spacing',
                    'protocol_name',
                )
                .order_by('study_id', 'series_number', 'series_uid')
            )

            return Response({
                'count': series_qs.count(),
                'results': list(series_qs)
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DoctorInfoView(APIView):
    """현재 로그인한 의사 정보 조회/수정 API"""
    permission_classes = [IsDoctor]

    def get(self, request):
        """
        현재 로그인한 의사의 상세 정보 조회
        """
        try:
            doctor = Doctor.objects.select_related('department').get(user=request.user)
            serializer = DoctorListSerializer(doctor)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Doctor.DoesNotExist:
            return Response({
                'error': '의사 정보를 찾을 수 없습니다.'
            }, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def patch(self, request):
        """
        현재 로그인한 의사의 정보 수정
        """
        try:
            doctor = Doctor.objects.select_related('department').get(user=request.user)

            # 수정 가능한 필드들
            allowed_fields = ['name', 'phone', 'room_number']

            # date_of_birth는 별도 처리 (날짜 형식 검증)
            if 'date_of_birth' in request.data and request.data['date_of_birth']:
                doctor.date_of_birth = request.data['date_of_birth']

            for field in allowed_fields:
                if field in request.data:
                    setattr(doctor, field, request.data[field])

            doctor.save()

            serializer = DoctorListSerializer(doctor)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Doctor.DoesNotExist:
            return Response({
                'error': '의사 정보를 찾을 수 없습니다.'
            }, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DoctorMedicalRecordListView(APIView):
    """
    의사 본인의 진료 기록(Encounter) 목록 조회 API
    - 검색 (환자명, 환자ID)
    - 날짜 필터링
    """
    permission_classes = [IsDoctor]

    def get(self, request):
        try:
            # 1. 현재 로그인한 의사 찾기
            doctor = Doctor.objects.get(user=request.user)

            # 2. 쿼리 파라미터
            search = request.query_params.get('search', '')
            start_date = request.query_params.get('start_date')
            end_date = request.query_params.get('end_date')
            
            # 3. 기본 쿼리셋 (assigned_doctor 기준)
            encounters = Encounter.objects.filter(assigned_doctor=doctor).select_related('patient')

            # 4. 검색 필터 (Trigram 적용 - Patient 검색 재사용)
            if search:
                # 1) 환자 검색 (유사도 순 정렬된 결과)
                target_patients = Patient.objects.search_patient(search)
                # 2) 해당 환자들의 진료 기록 필터링
                encounters = encounters.filter(patient__in=target_patients).order_by('-start_time')
            else:
                 encounters = encounters.order_by('-start_time')

            # 5. 날짜 필터
            if start_date:
                encounters = encounters.filter(start_time__date__gte=start_date)
            if end_date:
                encounters = encounters.filter(start_time__date__lte=end_date)

            # 6. 정렬 (검색어 없을 때만 시간순, 검색어 있으면 위에서 이미 정렬됨)
            if not search:
                encounters = encounters.order_by('-start_time')

            # 7. 시리얼라이즈
            serializer = EncounterSerializer(encounters, many=True)

            return Response({
                'count': encounters.count(),
                'results': serializer.data
            }, status=status.HTTP_200_OK)

        except Doctor.DoesNotExist:
             return Response({'error': '의사 정보를 찾을 수 없습니다.'}, status=404)
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class CreateLabOrderView(APIView):
    """LabOrder 생성 API"""
    permission_classes = [IsDoctor]

    def post(self, request):
        try:
            # Frontend sends snake_case IDs, need to map to serializer fields if needed
            # Or serializer fields should match.
            # DRF ModelSerializer expects 'patient', 'encounter', 'doctor' as PKs by default.
            
            data = request.data.copy()
            
            # 1. Doctor handling
            try:
                doctor = Doctor.objects.get(user=request.user)
                data['doctor'] = doctor.doctor_id
            except Doctor.DoesNotExist:
                # If helper/admin calling this API on behalf of doctor (unlikely but possible)
                if 'doctor_id' in data:
                    data['doctor'] = data['doctor_id']
                else:
                    return Response({'error': '의사 정보를 찾을 수 없습니다.'}, status=status.HTTP_404_NOT_FOUND)

            # 2. Map frontend IDs to serializer fields
            if 'patient_id' in data:
                data['patient'] = data['patient_id']
            if 'encounter_id' in data:
                data['encounter'] = data['encounter_id']

            serializer = CreateLabOrderSerializer(data=data)
            if serializer.is_valid():
                order = serializer.save()
                encounter_id = data.get('encounter')
                if encounter_id:
                    try:
                        encounter = Encounter.objects.get(encounter_id=encounter_id)
                        if encounter.workflow_state not in [Encounter.WorkflowState.COMPLETED, Encounter.WorkflowState.CANCELLED]:
                            encounter.transition_to(Encounter.WorkflowState.WAITING_ORDER)
                    except Encounter.DoesNotExist:
                        pass
            
                # WebSocket 알림 전송 (관리자에게)
                try:
                    channel_layer = get_channel_layer()
                    async_to_sync(channel_layer.group_send)(
                        "clinic_dashboard",  # 관리자가 구독 중인 그룹
                        {
                            "type": "new_order",
                            "message": f"{data.get('patient_name', '환자')}의 혈액검사 오더가 도착했습니다.",
                            "data": {
                                "order_type": "LAB",
                                "patient_id": data.get('patient'),
                                "doctor_id": data.get('doctor')
                            }
                        }
                    )
                except Exception as wse:
                     print(f"WebSocket send failed: {wse}")

                return Response({
                    'message': '오더가 성공적으로 생성되었습니다.',
                    'order': serializer.data
                }, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class CreateDoctorToRadiologyOrderView(APIView):
    """영상 검사 오더 생성 API"""
    permission_classes = [IsDoctor]

    def post(self, request):
        try:
            data = request.data.copy()
            
            # 1. Doctor handling
            try:
                doctor = Doctor.objects.get(user=request.user)
                data['doctor'] = doctor.doctor_id
            except Doctor.DoesNotExist:
                 if 'doctor_id' in data:
                    data['doctor'] = data['doctor_id']
                 else:
                    return Response({'error': '의사 정보를 찾을 수 없습니다.'}, status=status.HTTP_404_NOT_FOUND)

            # 2. Map IDs
            if 'patient_id' in data:
                data['patient'] = data['patient_id']
            if 'encounter_id' in data:
                data['encounter'] = data['encounter_id']

            serializer = CreateDoctorToRadiologyOrderSerializer(data=data)
            if serializer.is_valid():
                order = serializer.save()
                encounter_id = data.get('encounter')
                if encounter_id:
                    try:
                        encounter = Encounter.objects.get(encounter_id=encounter_id)
                        if encounter.workflow_state not in [Encounter.WorkflowState.COMPLETED, Encounter.WorkflowState.CANCELLED]:
                            encounter.transition_to(Encounter.WorkflowState.WAITING_ORDER)
                    except Encounter.DoesNotExist:
                        pass

                # WebSocket 알림 전송 (관리자에게)
                try:
                    channel_layer = get_channel_layer()
                    async_to_sync(channel_layer.group_send)(
                        "clinic_dashboard",
                        {
                            "type": "new_order",
                            "message": f"{data.get('patient_name', '환자')}의 영상검사 오더가 도착했습니다.",
                            "data": {
                                "order_type": "IMAGING",
                                "patient_id": data.get('patient'),
                                "doctor_id": data.get('doctor')
                            }
                        }
                    )
                except Exception as wse:
                     print(f"WebSocket send failed: {wse}")

                return Response({
                    'message': '영상 검사 오더가 성공적으로 생성되었습니다.',
                    'order': serializer.data
                }, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PatientLabOrdersView(APIView):
    """특정 환자의 Lab Orde 목록 조회 API"""
    permission_classes = [IsAuthenticated]

    def get(self, request, patient_id):
        try:
            # 최근 오더 순으로 정렬
            orders = LabOrder.objects.filter(patient_id=patient_id).order_by('-created_at')

            # 페이지네이션 등은 필요 시 추가 (지금은 전체 반환 or limit)
            limit = request.query_params.get('limit')
            if limit:
                orders = orders[:int(limit)]

            serializer = LabOrderSerializer(orders, many=True)
            return Response({
                'count': len(serializer.data),
                'results': serializer.data
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class AnnouncementListView(APIView):
    """공지사항 목록 조회 API"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """
        공지사항 목록 조회
        - is_active=True인 공지사항만 조회
        - 중요 공지사항이 먼저 나오도록 정렬 (ordering = ['-is_important', '-created_at'])

        Query Parameters:
        - limit: 조회할 개수 (기본값: 전체)
        - type: 공지 유형 필터 (GENERAL, URGENT, EVENT, MAINTENANCE)
        - important_only: true인 경우 중요 공지만 조회
        """
        try:
            # 기본 쿼리: 활성 공지사항만
            announcements = Announcement.objects.filter(is_active=True)

            # 현재 시간 기준으로 유효한 공지사항만 (expires_at이 null이거나 미래인 것)
            now = timezone.now()
            announcements = announcements.filter(
                Q(expires_at__isnull=True) | Q(expires_at__gt=now)
            )

            # 필터: 공지 유형
            announcement_type = request.query_params.get('type')
            if announcement_type:
                announcements = announcements.filter(announcement_type=announcement_type)

            # 필터: 중요 공지만
            important_only = request.query_params.get('important_only')
            if important_only and important_only.lower() == 'true':
                announcements = announcements.filter(is_important=True)

            # 정렬: 중요 공지가 먼저, 그 다음 최신순
            announcements = announcements.order_by('-is_important', '-created_at')

            # 개수 제한
            limit = request.query_params.get('limit')
            if limit:
                announcements = announcements[:int(limit)]

            serializer = AnnouncementSerializer(announcements, many=True)
            return Response({
                'count': len(serializer.data),
                'results': serializer.data
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AnnouncementDetailView(APIView):
    """공지사항 상세 조회 API"""
    permission_classes = [IsAuthenticated]

    def get(self, request, announcement_id):
        """공지사항 상세 조회"""
        try:
            announcement = Announcement.objects.get(announcement_id=announcement_id)
            serializer = AnnouncementSerializer(announcement)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Announcement.DoesNotExist:
            return Response({'error': '공지사항을 찾을 수 없습니다.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ============================================================
# [통합 분석 LLM] 혈액 검사 + 유전체 변이 데이터 종합 분석
# ============================================================

class IntegratedLLMAnalysisView(APIView):
    """
    MedGemma를 활용한 통합 임상 분석 API
    - 혈액 검사 데이터 + 유전체 변이 패턴 → 심층 해석 + 치료 권고안 생성
    """
    permission_classes = [IsAuthenticated] 

    def post(self, request):
        patient_id = request.data.get('patient_id')
        if not patient_id:
            return Response({'error': 'patient_id가 필요합니다.'}, status=400)

        try:
            # 1. 환자의 최근 혈액 검사 데이터
            lab_info = {}
            last_lab = LabResult.objects.filter(patient_id=patient_id).order_by('-test_date').first()
            if last_lab:
                lab_info = {
                    "test_date": str(last_lab.test_date) if last_lab.test_date else None,
                    "AFP": float(last_lab.afp) if last_lab.afp else None,
                    "Albumin": float(last_lab.albumin) if last_lab.albumin else None,
                    "Bilirubin_Total": float(last_lab.bilirubin_total) if last_lab.bilirubin_total else None,
                    "Platelet": float(last_lab.platelet) if last_lab.platelet else None,
                    "PT_INR": float(last_lab.pt_inr) if last_lab.pt_inr else None,
                    "Creatinine": float(last_lab.creatinine) if last_lab.creatinine else None,
                    "MELD_Score": float(last_lab.meld_score) if last_lab.meld_score else None,
                    "Child_Pugh_Class": last_lab.child_pugh_class,
                    "ALBI_Score": float(last_lab.albi_score) if last_lab.albi_score else None,
                    "ALBI_Grade": last_lab.albi_grade,
                }

            # 2. 환자의 유전체 변이 데이터 (pathway_scores가 JSONField)
            genomic_info = {}
            last_genomic = GenomicData.objects.filter(patient_id=patient_id).order_by('-created_at').first()
            if last_genomic and last_genomic.pathway_scores:
                genomic_info = last_genomic.pathway_scores

            # 3. 데이터 없으면 에러
            if not lab_info and not genomic_info:
                return Response({'error': '분석할 환자의 임상 데이터가 없습니다.'}, status=404)

            # 4. LLM에 보낼 데이터 구성
            combined_payload = {
                "patient_id": patient_id,
                "blood_test": lab_info,
                "genomic_pathways": genomic_info
            }

            # 5. 시스템 프롬프트 (통합 분석용)
            system_prompt = """
당신은 간세포암(HCC) 전문의를 보조하는 AI 임상 분석가입니다.
제공된 임상 데이터를 바탕으로, 의료진 간 커뮤니케이션에 적합한 **[간 종양 통합 소견서]**를 작성하시오.

[작성 원칙]
1. **서식:** 리스트 불릿(*)이나 마크다운 볼드체(**)를 사용하지 마시오. 일반 텍스트와 하이픈(-)만 사용하여 깔끔하게 작성하시오.
2. **간결성:** 정상 범위 설명이나 사전적 정의 배제. 핵심 소견만 명확히 기술하시오.
3. **전문성:** '중간 정도' 같은 모호한 표현을 피하고, '고위험군', '저위험군', '재발 위험군' 등 명확한 임상 용어를 사용하여 서술하시오.
4. **직접 작성:** 가이드용 예시 문구나 대괄호([])를 그대로 베껴 쓰지 말고, 실제 환자 데이터에 기반한 분석 내용으로 문장을 완성하시오.

[출력 양식]

간 종양 통합 소견서

1. 주요 임상 소견

- 간 기능 : (예: Child-Pugh A 및 ALBI Grade 1로 간 예비능 양호함. 단, MELD 점수 고려 시 주의 요망.)
- 종양 표지자 : (예: AFP 12.5 ng/mL로 경미한 상승 소견 보임.)

2. 유전체 변이 해석

- (활성화 점수가 높은 상위 3개 경로만 선택하여 기술)
- 경로명 (Score 점수) : (임상적 의미 한 줄 요약. 예: 종양의 공격적인 증식 및 대사 활성 시사.)

3. 종합 평가

(이곳에는 템플릿 문구를 사용하지 마시오. 간 기능 상태와 유전체 변이 특성을 종합하여, 환자의 예후 및 재발 위험도를 전문의 소견 형태로 직접 명확하게 서술하시오.)

4. 제언 (Plan)

추가 검사 :
- (꼭 필요한 검사명만 나열)
치료 전략 :
- (환자 상태에 적합한 치료법 및 추적 관찰 계획 제안)

※ 참고 : 본 소견서는 AI 보조 도구에 의해 생성되었으며, 최종 임상 판단은 담당 의료진이 수행해야 합니다.
"""

            # 6. 기존 팀원이 만든 LM Studio 서비스 호출
            report_text = generate_lmstudio_report(
                payload=combined_payload,
                system_content=system_prompt
            )

            return Response({"report": report_text})

        except Exception as e:
            return Response({"error": str(e)}, status=500)